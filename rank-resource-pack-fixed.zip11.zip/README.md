# Reapers Rank Pack

For Minecraft Java 1.21.11 (resource pack format 75).

The 12 rank graphics are registered as bitmap glyphs under private-use characters U+E001 through U+E00C. They are available in both `minecraft:default` and the dedicated `minecraft:rank` font, so a rank prefix containing the mapped character can render in normal chat/tab text without a font override.

- PNGs: `assets/minecraft/textures/font/`
- Font definitions: `assets/minecraft/font/default.json` and `rank.json`
- Exact character-to-rank mapping: `rank-mapping.json`

The pack only supplies the rank graphics. Add the matching private-use character from `rank-mapping.json` to each rank prefix in your chat/tab plugin, and make sure players have this pack enabled.

Ikony jsou vysoké 10 jednotek (ascent 8), aby se vešly do řádku chatu/tablistu; zdrojové PNG mají 20 px na výšku, takže jsou při GUI scale 2 ostré 1:1.
`default.json` obsahuje jen rank glyfy, vanilla znaky se do něj přidají automaticky z vanilla balíčku.
