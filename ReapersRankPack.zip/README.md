# Reapers Rank Pack

Built for Minecraft Java 1.21.11 (resource pack format 75).

All 12 supplied rank PNGs are mapped in `assets/minecraft/font/rank.json`. Textures are in `assets/minecraft/textures/font/`.

Use the font id `minecraft:rank` in a Minecraft text component. Example for the first icon:

```json
{ "text": "", "font": "minecraft:rank" }
```

See `rank-mapping.json` for every icon and its private-use codepoint. Your TAB/chat plugin must output the codepoint and use the custom font to display a badge. The resource pack alone does not configure server prefixes.
